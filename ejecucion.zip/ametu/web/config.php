<?php
define('ProPayPal', 0); // Valor cero (0) modo prueba
if(ProPayPal){
    define("PayPalClientId", "*********************");
    define("PayPalSecret", "*********************");
    define("PayPalBaseUrl", "https://api.paypal.com/v1/");
    define("PayPalENV", "production");
} else {
    define("PayPalClientId", "Ac6oeG_toRnUbppN5IQVYDEPvhXhTrHjLFLgXlTtTVaqaBKVitVvuhPCmBPdTcnHXb3zc4_uiMvlkWis");
    define("PayPalSecret", "EMH3d23diRKKncOYOfAwzwMTDG3U20c8wwFupneVUnXTFVqn4hwF-4X2DJRCznY58CXaAQ25Omt3kWAk");
    define("PayPalBaseUrl", "https://api.sandbox.paypal.com/v1/");
    define("PayPalENV", "sandbox");
}
?>