    <?php
        $servername = "localhost:3306";
        $database = "ametu";
        $username = "root";
        $password = "";
        // Create connection
        $conn = mysqli_connect($servername, $username, $password, $database);
        // Check connection
        if (!$conn) {
            die("Connection failed: " . mysqli_connect_error());
        }
        echo "Connected successfully";
        $sql = "SELECT * FROM product";
        $result = mysqli_query($conn, $sql);
        while($row = mysqli_fetch_array($result)) {
            echo "Producto: " . $row["Producto"];
        }

        mysqli_close($conn);
    ?>