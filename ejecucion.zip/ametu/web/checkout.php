<?php
    $product = $_POST['nombre'];
    $quantity = $_POST['quantity'];
    $price = $_POST['precio'];
    $total = $_POST['total'];
    $servername = "localhost:3306";
    $database = "ametu";
    $username = "root";
    $password = "";
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $database);
    $sql = "SELECT * FROM producto, provedores";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_array($result);
/*    echo $product[0];
    echo $quantity[0];
    echo $price[0];*/
?>
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>AMETU</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Downy Shoes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //custom-theme -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/shop.css" type="text/css" media="screen" property="" />
	<link href="css/style7.css" rel="stylesheet" type="text/css" media="all" />
	<!-- Owl-carousel-CSS -->
	<link rel="stylesheet" type="text/css" href="css/checkout.css">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- font-awesome-icons -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- //font-awesome-icons -->
	<link href="//fonts.googleapis.com/css?family=Montserrat:100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
	<!-- banner -->
	<div class="banner_top innerpage" id="home">
		<div class="wrapper_top_w3layouts">
			<div class="header_agileits">
				<div class="logo inner_page_log">
					<h1><a class="navbar-brand" href="index.html"><span>A</span> <i>METU</i></a></h1>
				</div>
				<div class="overlay overlay-contentpush">
					<button type="button" class="overlay-close"><i class="fa fa-times" aria-hidden="true"></i></button>

					<nav>
						<ul>
							<li><a href="index.html" class="active">Inicio</a></li>
<!--							<li><a href="about.html">Sobre nosotos</a></li>-->
							<li><a href="shop.php">Comprar</a></li>
							<li><a href="contact.html">Contacto</a></li>
						</ul>
					</nav>
				</div>
				<div class="mobile-nav-button">
					<button id="trigger-overlay" type="button"><i class="fa fa-bars" aria-hidden="true"></i></button>
				</div>
				<!-- cart details -->
				<div class="top_nav_right">
					<div class="shoecart shoecart2 cart cart box_1">
						<form action="#" method="post" class="last">
							<input type="hidden" name="cmd" value="_cart">
							<input type="hidden" name="display" value="1">
							<button class="top_shoe_cart" type="submit" name="submit" value=""><i class="fa fa-cart-arrow-down" aria-hidden="true"></i></button>
						</form>
					</div>
				</div>
			</div>
		</div>
		<!-- //cart details -->
		<!-- search -->
		<div class="search_w3ls_agileinfo">
			<div class="cd-main-header">
				<ul class="cd-header-buttons">
					<li><a class="cd-search-trigger" href="#cd-search"> <span></span></a></li>
				</ul>
			</div>
			<div id="cd-search" class="cd-search">
				<form action="#" method="post">
					<input name="Search" type="search" placeholder="Click enter after typing...">
				</form>
			</div>
		</div>
		<!-- //search -->
		<div class="clearfix"></div>
		<!-- /banner_inner -->
		<div class="services-breadcrumb_w3ls_agileinfo">
			<div class="inner_breadcrumb_agileits_w3">

				<ul class="short">
					<li><a href="index.html">Inicio</a><i>|</i></li>
					<li>Contacto</li>
				</ul>
			</div>
		</div>
		<!-- //banner_inner -->
	</div>

	<!-- //banner -->
	<!-- top Products -->
	<div class="ads-grid_shop">
		<div class="shop_inner_inf">
			<div class="privacy about">
				<h3>Chec<span>kout</span></h3>

				<div class="checkout-right">
					<h4>Tu carrito de compras contiene: <span><?php echo sizeof($product)?> productos</span></h4>
					<table class="timetable_sub">
						<thead>
							<tr>
								<th>Producto</th>
                                <th>Cantidad</th>

								<th>Precio</th>
								<th>Eliminar</th>
							</tr>
						</thead>
						<tbody>
                        <?php
                            
                            for($i = 0; $i < sizeof($product);$i++){
                        ?>
							<tr class="rem1">
                                <td class="invert"><?php echo $product[$i]?></td>
								<td class="invert">
									<div class="quantity">
										<div class="quantity-select">
<!--											<div class="entry value-minus">&nbsp;</div>-->
											<div class="entry value"><span><?php echo $quantity[$i]?></span></div>
<!--											<div class="entry value-plus active">&nbsp;</div>-->
										</div>
									</div>
								</td>

								<td class="invert"><?php echo $price[$i]?></td>
								<td class="invert">
									<div class="rem">
										<div class="close1"> </div>
									</div>

								</td>
							</tr>
                        <?php
                            }
                        ?>
						</tbody>
					</table>
				</div>
				<div class="checkout-left">
					<div class="col-md-4 checkout-left-basket">
						<h4>Carrito</h4>
						<ul>
                        <?php
                            for($i = 0; $i < sizeof($product);$i++){ 
                        ?>
							<li><?php echo $product[$i]?> <span>  <?php echo $price[$i]?> </span></li>
                        <?php
                            }
                        ?>
							<li>Total <span><?php echo $total?></span></li>
						</ul>
					</div>
					<div class="col-md-8 address_form">
						<h4>Direccion de entrega</h4>
						<form action="payment.php" method="post" class="creditly-card-form agileinfo_form">
							<section class="creditly-wrapper wrapper">
								<div class="information-wrapper">
									<div class="first-row form-group">
										<div class="controls">
											<label class="control-label">Nombre completo: </label>
											<input class="billing-address-name form-control" type="text" name="name" placeholder="Nombre completo">
										</div>
										<div class="card_number_grids">
											<div class="card_number_grid_left">
												<div class="controls">
													<label class="control-label">Telefono:</label>
													<input class="form-control" type="text" placeholder="Telefono">
												</div>
											</div>
											<div class="card_number_grid_right">
												<div class="controls">
													<label class="control-label">Ciudad: </label>
													<input class="form-control" type="text" placeholder="Ciudad">
												</div>
											</div>
											<div class="clear"> </div>
										</div>
                                        <div class="controls">
											<label class="control-label">Delegacion/Municipio: </label>
											<input class="form-control" type="text" placeholder="Delegacion/Municipio">
										</div>
										<div class="controls">
											<label class="control-label">Calle: </label>
											<input class="form-control" type="text" placeholder="Calle">
										</div>
										<div class="controls">
											<label class="control-label">Tipo de direccion: </label>
											<select class="form-control option-w3ls">
																							<option>Oficina</option>
																							<option>Casa</option>
																							<option>Comercial</option>
							
																					</select>
										</div>
									</div>
<!--									<button class="submit check_out">Entregar a esta direccion</button>-->
								</div>
							</section>
						</form>
						<div class="checkout-right-basket">
							<a href="paypalCheckout.php?total=<?php echo $total?>">Realizar pago </a>
						</div>
					</div>

					<div class="clearfix"> </div>


					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<!-- //top products -->
		<!-- footer -->
		<div class="footer_agileinfo_w3">
			<div class="footer_inner_info_w3ls_agileits">
				<div class="col-md-3 footer-left">
				<h2><a href="index.html"><span>A</span>METU </a></h2>
				<p>Empresa que busca ligar/unir el mercado textil de diversas instituciones gubernamentales con su potencial cliente, generando una red de abastecimiento más eficiente y eficaz.</p>
					<ul class="social-nav model-3d-0 footer-social social two">
						<li>
							<a href="#" class="facebook">
								<div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="twitter">
								<div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="instagram">
								<div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div>
							</a>
						</li>
						<li>
							<a href="#" class="pinterest">
								<div class="front"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
								<div class="back"><i class="fa fa-linkedin" aria-hidden="true"></i></div>
							</a>
						</li>
					</ul>
				</div>
				<div class="col-md-9 footer-right">
					<div class="sign-grds">
					<div class="col-md-4 sign-gd">
						<h4>Nuestro <span>Sitio</span> </h4>
						<ul>
							<li><a href="index.html">Inicio</a></li>
							<li><a href="about.html">Sobre nosotros</a></li>
							<li><a href="shop.php">Comprar</a></li>
							<li><a href="contact.html">Contacto</a></li>
						</ul>
					</div>

					<div class="col-md-5 sign-gd-two">
						<h4>Nuestros <span>Datos</span></h4>
						<div class="address">
							<div class="address-grid">
								<div class="address-left">
									<i class="fa fa-phone" aria-hidden="true"></i>
								</div>
								<div class="address-right">
									<h6>Numero telefonico</h6>
									<p>+525567983299</p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="address-grid">
								<div class="address-left">
									<i class="fa fa-envelope" aria-hidden="true"></i>
								</div>
								<div class="address-right">
									<h6>Correo electronico</h6>
									<p>Email :<a href="mailto:example@email.com"> ametu.oficial@uniformes.com.mx</a></p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="address-grid">
								<div class="address-left">
									<i class="fa fa-map-marker" aria-hidden="true"></i>
								</div>
								<div class="address-right">
									<h6>Sitio web</h6>
									<p>www.ametu.com.mx</p>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					</div>
						<div class="clearfix"></div>
					</div>
				</div>
				<div class="clearfix"></div>

				<p class="copy-right-w3ls-agileits">&copy 2019 AMETU. All rights reserved | Design by <a href="http://w3layouts.com/">w3layouts</a>
			</div>
		</div>
	</div>
	<!-- //footer -->
<!--    <a href="#home" id="toTop" class="scroll" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>-->
	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<!-- //js -->
	<!-- cart-js -->
	<script src="js/minicart.js"></script>
	<script>
		shoe.render();

		shoe.cart.on('shoe_checkout', function (evt) {
			var items, len, i;

			if (this.subtotal() > 0) {
				items = this.items();

				for (i = 0, len = items.length; i < len; i++) {}
			}
		});
	</script>
	<!-- //cart-js -->
	<!-- /nav -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/demo1.js"></script>
	<!-- //nav -->
	<!--search-bar-->
	<script src="js/search.js"></script>
	<!--//search-bar-->
	<!--quantity-->
	<script>
		$('.value-plus').on('click', function () {
			var divUpd = $(this).parent().find('.value'),
				newVal = parseInt(divUpd.text(), 10) + 1;
			divUpd.text(newVal);
		});

		$('.value-minus').on('click', function () {
			var divUpd = $(this).parent().find('.value'),
				newVal = parseInt(divUpd.text(), 10) - 1;
			if (newVal >= 1) divUpd.text(newVal);
		});
	</script>
	<!--quantity-->
	<script>
		$(document).ready(function (c) {
			$('.close1').on('click', function (c) {
				$('.rem1').fadeOut('slow', function (c) {
					$('.rem1').remove();
				});
			});
		});
	</script>
	<script>
		$(document).ready(function (c) {
			$('.close2').on('click', function (c) {
				$('.rem2').fadeOut('slow', function (c) {
					$('.rem2').remove();
				});
			});
		});
	</script>
	<script>
		$(document).ready(function (c) {
			$('.close3').on('click', function (c) {
				$('.rem3').fadeOut('slow', function (c) {
					$('.rem3').remove();
				});
			});
		});
	</script>

	<!-- start-smoth-scrolling -->
	<script type="text/javascript" src="js/move-top.js"></script>
	<script type="text/javascript" src="js/easing.js"></script>
	<script type="text/javascript">
		jQuery(document).ready(function ($) {
			$(".scroll").click(function (event) {
				event.preventDefault();
				$('html,body').animate({
					scrollTop: $(this.hash).offset().top
				}, 1000);
			});
		});
	</script>
	<!-- //end-smoth-scrolling -->
	<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>


</body>

</html>