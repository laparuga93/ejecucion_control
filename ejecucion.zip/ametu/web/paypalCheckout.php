<?php
    $servername = "localhost:3306";
    $database = "ametu";
    $username = "root";
    $password = "";
    //$fecha = date("d-m-Y");
    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $database);
    /*for($i = 0; $i < sizeof($product);$i++){
        $sql = "INSERT INTO ventas (Cantidad, Fecha, IdP) VALUES ($quantity[$i],$fecha)";
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }*/

    $conn->close();
    //$result = mysqli_query($conn, $sql);
    //$row = mysqli_fetch_array($result);
/*    echo $product[0];
    echo $quantity[0];
    echo $price[0];*/
?><!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>PayPal</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type; X-UA-Compatible" content="text/html; charset=utf-8; IE=edge" />
	<meta name="keywords" content="Downy Shoes Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript">
		addEventListener("load", function () {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
    <!-- Load the required checkout.js script -->
    <script src="https://www.paypalobjects.com/api/checkout.js" data-version-4></script>

    <!-- Load the required Braintree components. -->
    <script src="https://js.braintreegateway.com/web/3.39.0/js/client.min.js"></script>
    <script src="https://js.braintreegateway.com/web/3.39.0/js/paypal-checkout.min.js"></script>

	<!-- //custom-theme -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link rel="stylesheet" href="css/shop.css" type="text/css" media="screen" property="" />
	<link href="css/style7.css" rel="stylesheet" type="text/css" media="all" />
	<!-- Owl-carousel-CSS -->
	<link href="css/easy-responsive-tabs.css" rel='stylesheet' type='text/css' />

	<link rel="stylesheet" type="text/css" href="css/checkout.css">
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
	<!-- font-awesome-icons -->
	<link href="css/font-awesome.css" rel="stylesheet">
	<!-- //font-awesome-icons -->
	<link href="//fonts.googleapis.com/css?family=Montserrat:100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800"
	    rel="stylesheet">
	<link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800" rel="stylesheet">
</head>

<body>
	<!-- top Products -->
	<div class="ads-grid_shop">
		<div class="shop_inner_inf">
                <div class="col-md-6">
                    <?php $resultado = intval(preg_replace('/[^0-9.]+/', '', $_GET['total']), 10) ?>
                    <form name="myform" action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
                        <input type="hidden" name="cmd" value="_xclick">
                        <input type="hidden" name="cancel_return" value="http://127.0.0.1:8080/edsa-AMETU/failure.html">
                        <input type="hidden" name="return" value="http://127.0.0.1:8080/edsa-AMETU/success.html">
                        <input type="hidden" name="business" value="sb-q347mp304972@business.example.com">
                        <input type="hidden" name="lc" value="C2">
                        <input type="hidden" name="item_name" value="Productos AMETU" />
                        <input type="hidden" name="amount" value="<?php echo $resultado?>">
<!--                        <input type="hidden" name="amount" value="320">-->
                        <input type="hidden" name="currency_code" value="MXN">
                        <input type="hidden" name="button_subtype" value="services">
                        <input type="hidden" name="no_note" value="0">
                    </form>
                    <script type="text/javascript">
                        document.myform.submit();
                    </script>

                </div>
                <div class="clearfix"></div>
			</div>

		</div>
	


</body>

</html>