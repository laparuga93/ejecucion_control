<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'PHPMailer\src\PHPMailer.php';
    require 'PHPMailer\src\Exception.php';
    require 'PHPMailer\src\SMTP.php';

    $email = new PHPMailer(TRUE);

    $email_to = 'laparuga93@gmail.com';
    $email_subject = 'Informacion de contacto AMETU'; 
 
    $company_name = $_POST['company_name']; // required
    $mail = $_POST['mail']; // required
    $giro = $_POST['giro']; // required
    $contact_name = $_POST['contact_name']; // not required
    $state = $_POST['state']; // required
    $municipio = $_POST['municipio']; // required
    $web_page = $_POST['web_page']; // required
    $region = $_POST['region']; // required
    $article = $_POST['article']; // not required
    $estimation = $_POST['estimation']; // required
    $message = $_POST['message']; // required
 
    $error_message = '';
 
    $email_message = "Formulario enviado.\n\n";
 
    function clean_string($string) {
      $bad = array('content-type','bcc:','to:','cc:','href');
      return str_replace($bad,'',$string);
    }
 
 
    $email_message .= "Nombre de la compañia: ".clean_string($company_name)."\n";
    $email_message .= "Mail: ".clean_string($mail)."\n";
    $email_message .= "Giro: ".clean_string($giro)."\n";
    $email_message .= "Nombre del contacto: ".clean_string($contact_name)."\n";
    $email_message .= "Estado: ".clean_string($state)."\n";
    $email_message .= "Municipio: ".clean_string($municipio)."\n";
    $email_message .= "Pagina web: ".clean_string($web_page)."\n";
    $email_message .= "Region: ".clean_string($region)."\n";
    $email_message .= "Articulo principal de interes: ".clean_string($article)."\n";
    $email_message .= "Estimacion de prendas: ".clean_string($estimation)."\n";
    $email_message .= "Mensaje: ".clean_string($message)."\n";

    //Tell PHPemailer to use SMTP
    $email->isSMTP();
    //Enable SMTP debugging
    // 0 = off (for production use)
    // 1 = client messages
    // 2 = client and server messages
    $email->SMTPDebug = 2;
    //Set the hostname of the email server
    $email->Host = 'smtp.gmail.com';
    // use
    // $email->Host = gethostbyname('smtp.gemail.com');
    // if your network does not support SMTP over IPv6
    //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
    $email->Port = 587;
    //Set the encryption system to use - ssl (deprecated) or tls
    $email->SMTPSecure = 'tls';
    //Whether to use SMTP authentication
    $email->SMTPAuth = true;
    //Username to use for SMTP authentication - use full eemail address for gemail
    $email->Username = "laparuga93@gmail.com";
    //Password to use for SMTP authentication
    $email->Password = "C4f3C4li3nt393";
    
    try {
       /* Set the mail sender. */
       $email->setFrom('laparuga93@gmail.com', 'Pau');
        
       /* Add a recipient.*/ 
       $email->addAddress($mail, 'Recipient');

       /* Set the subject. */
       $email->Subject = $email_subject;

       /* Set the mail message body. */
       $email->Body = $email_message;

       /* Finally send the mail. */
       $email->send();
       header("Location: success.html");
    }
    catch (Exception $e)
    {
       /* PHPMailer exception. */
       header("Location: failed.html");
       echo $e->errorMessage();
    }
    catch (\Exception $e)
    {
       /* PHP exception (note the backslash to select the global namespace Exception class). */
       header("Location: failed.html");
       echo $e->getMessage();
    }


?>